from django.apps import AppConfig


class SalaryConfig(AppConfig):
    name = 'salary'
