from django.apps import AppConfig


class TaxConfig(AppConfig):
    name = 'tax'
